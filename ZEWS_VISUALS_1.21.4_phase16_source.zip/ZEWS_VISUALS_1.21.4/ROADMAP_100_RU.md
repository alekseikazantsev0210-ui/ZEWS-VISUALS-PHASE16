# ZEWS VISUALS — дорожная карта 100 функций

**Статус исходников:** 98 модулей/переключателей объявлено после удаления радара и связанных индикаторов. Статическая проверка проходит. Это не подтверждает компиляцию Java или игровой тест.

## Реализовано в исходниках — 98 (заявлено в коде; нужен runtime-тест)

1. Watermark
2. FPS Counter
3. Coordinates
4. Direction
5. Biome Name
6. Clock (время мира)
7. Memory Usage
8. Held Item
9. Armor Status
10. Potion Effects
11. CPS Counter (левая/правая кнопка)
12. Keystrokes
13. Sprint Status
14. Sneak Status
15. Crosshair Dot
16. Module List
17. Low Health Warning
18. View Bobbing toggle
19. Show System Time
20. Show Server Address
21. Armor Durability
22. Food Level
23. Day Counter
24. Chunk Coordinates
25. Movement Speed
26. Ping
27. Light Level
28. Target Block
29. Held Item Durability
30. Nether Coordinates
31. Player Health
33. Facing Angle
34. Dimension
35. Experience Status
36. Target Name
37. Target Health
38. Target Distance
39. Target Armor
40. World Time Ticks
41. FPS Graph
42. Frame Time
43. Memory Percentage
44. Free Memory
45. Block Position
46. Compass Letters
47. Durability Warning
48. Potion Duration
49. Totem Count
50. Golden Apple Count
51. Arrow Count
52. Armor Points
53. Health Bar
54. Hunger Warning
55. Air Level
56. Ground Status
57. Movement State
58. Precise Coordinates
59. Mouse Keystrokes
60. CPS Graph
61. 12 Hour Clock
62. Potion Compact Mode
63. Armor Icons
64. Item Durability Bar
65. HUD Visibility Hotkey (F8, включается в меню)
66. Fullbright (gamma с восстановлением исходного значения; требует игрового теста)
67. Dynamic Crosshair
68. Crosshair Hit Color
69. HUD Text Background

## Дополнительные настройки и исправления
- Меню на Right Shift; поиск модулей и фильтр категорий.
- Профили `default`, `pvp`, `minimal`.
- Импорт/экспорт JSON, общий экспорт и экспорт с именем профиля.
- RGB-поля акцентного цвета, масштаб HUD, прозрачность фона текста, настройка gap и толщины динамического прицела.
- Порог предупреждения о прочности настраивается от 5% до 50%.
- Сброс выбранной категории или всего текущего профиля.
- Резервная копия конфигурации и запись через временный файл.
- Настройки ограничиваются допустимыми диапазонами при загрузке.

## Оставшиеся технические задачи — не все функции реализованы

70. Перетаскивание HUD-элементов мышью и сохранение координат каждого элемента.
71. Отдельные горячие клавиши для модулей с экраном назначения клавиш.
72. Интерфейс управления всеми профилями и удалением профиля.
73. Звуки интерфейса с переключателем.
74. Анимация открытия меню.
75. Настройка gap и толщины динамического прицела через меню — реализована в исходниках; требуется игровой тест.
76. Отдельные настройки каждого модуля.
77. Автосохранение по настраиваемому интервалу и корректная обработка выключения.
78. Переключатель подробного логирования.
79. Восстановление исходных игровых настроек при отключении отдельных функций.
80. Предупреждение о конфликтах с другими HUD/рендер-модами.
81. TPS — только при наличии достоверного источника данных.
82. Настраиваемое расположение Keystrokes.
83. Стили индикатора спринта.
84. Стили индикатора приседания.
85. Звук предупреждения о низком здоровье.
86. Более гибкие условия предупреждения о прочности.
87. Отдельный экспорт/импорт профиля из UI с выбором файла.
88. Clear Water через Mixin (нужны тесты совместимости с рендерерами).
89. Отключение погодных частиц через Mixin.
90. Настройка огненного overlay через Mixin.
91. Настройка pumpkin overlay через Mixin.
92. Переключатель виньетки через Mixin.
93. Настройка наклона камеры при получении урона через Mixin.
94. Настраиваемый цвет обводки блока через Mixin.
95. Полноценная RGB-настройка цвета обводки блока.
96. Проверка совместимости с Sodium/Iris и другими рендер-модами.
97. Поддержка разных разрешений и масштабов GUI для всех экранных элементов.
98. Проверка импортированных конфигов на повреждённые и неизвестные значения.
99. GitHub Actions workflow добавлен; нужно запустить удалённую сборку и подтвердить успешный артефакт.
100. Запуск Minecraft Java 1.21.4 и игровой smoke-test на Windows.

## Что не подтверждено
- Нет успешного вывода `BUILD SUCCESSFUL` для текущего исходника.
- Статическая проверка не заменяет компиляцию и запуск Minecraft.
- Функции, требующие Mixin, перечислены как задачи и не считаются реализованными.


## Добавлено в Phase 15
- [x] Ping Graph
- [x] Block Reach Meter
- [x] Velocity Vector
- [x] Resource Alert Panel
- [x] Biome & Dimension Card
- [x] Inventory Durability Scan
- [x] Status Effect Count
- [x] Air Safety Meter

## Добавлено в Phase 14
- [x] Combat Readiness Panel
- [x] Damage Flash Overlay
- [x] Attack Cooldown Meter
- [x] Potion Timeline
- [x] Armor Loadout Panel
- [x] Fall Distance Meter
- [x] Hotbar Item Spotlight
- [x] Weather & Time Card
- [x] Low Health Vignette


## Примечание к Phase 15
Дорожная карта первоначально перечисляла 30 оставшихся технических задач. Добавление 100 переключателей не означает завершение всех задач: перетаскивание HUD, отдельные бинды, полноценный редактор позиций, Mixin-оверлеи, совместимость с Sodium/Iris и запуск smoke-test остаются отдельной работой. Не считать мод проверенным до успешной сборки и теста в Minecraft 1.21.4.
