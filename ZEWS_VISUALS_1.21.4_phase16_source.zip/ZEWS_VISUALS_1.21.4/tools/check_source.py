#!/usr/bin/env python3
"""Fast offline sanity checks for ZEWS VISUALS source (not a Java compiler)."""
import json
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = root / "src/main/java/com/zewsvisuals/ZewsVisuals.java"
manifest = root / "src/main/resources/fabric.mod.json"
en_lang = root / "src/main/resources/assets/zewsvisuals/lang/en_us.json"
ru_lang = root / "src/main/resources/assets/zewsvisuals/lang/ru_ru.json"
errors = []
if not source.is_file():
    errors.append("Missing main Java source")
if not manifest.is_file():
    errors.append("Missing Fabric manifest")
if not en_lang.is_file() or not ru_lang.is_file():
    errors.append("Missing English/Russian keybind translations")
if errors:
    print("SOURCE CHECK FAILED")
    print("\n".join("- " + e for e in errors))
    sys.exit(1)
text = source.read_text(encoding="utf-8")
try:
    data = json.loads(manifest.read_text(encoding="utf-8"))
    if data.get("id") != "zewsvisuals":
        errors.append("Manifest mod id must be zewsvisuals")
    if "com.zewsvisuals.ZewsVisuals" not in data.get("entrypoints", {}).get("client", []):
        errors.append("Client entrypoint is missing")
    json.loads(en_lang.read_text(encoding="utf-8"))
    json.loads(ru_lang.read_text(encoding="utf-8"))
except Exception as exc:
    errors.append(f"Invalid fabric.mod.json: {exc}")
features = re.findall(r'add\("([^\"]+)",\s*"([^\"]+)",\s*(?:true|false)\);', text)
names = [name for name, _ in features]
if len(names) != len(set(names)):
    errors.append("Duplicate feature names detected")
if len(names) < 98:
    errors.append(f"Unexpectedly low feature count: {len(names)}")
for required in ["Target Name", "Target Health", "Target Distance", "CPS Graph", "HUD Visibility Hotkey", "Item Durability Bar", "Fullbright", "Dynamic Crosshair", "Crosshair Hit Color", "HUD Text Background", "Target Health Bar", "Armor Durability Bars", "Compass Strip", "Target Health Percent", "Jump Status", "Swimming Status", "Experience Progress Bar", "Health Percentage", "Hunger Percentage", "Armor Durability Percent", "Target Entity Type", "Target Distance Exact", "Underwater Warning", "Combat Readiness Panel", "Damage Flash Overlay", "Attack Cooldown Meter", "Potion Timeline", "Armor Loadout Panel", "Fall Distance Meter", "Hotbar Item Spotlight", "Weather & Time Card", "Low Health Vignette", "Ping Graph", "Block Reach Meter", "Velocity Vector", "Resource Alert Panel", "Biome & Dimension Card", "Inventory Durability Scan", "Status Effect Count", "Air Safety Meter"]:
    if required not in names:
        errors.append(f"Missing expected feature: {required}")
for required_setting in ["hudScale", "hudBackgroundOpacity", "durabilityWarningPercent", "crosshairGap", "crosshairThickness"]:
    if required_setting not in text:
        errors.append(f"Missing expected setting: {required_setting}")
if 'Text.literal(filterCategory.equals("All") ? "Filter: All" : "Filter: " + filterCategory)' not in text:
    errors.append("Category filter button should display the selected category")
if 'if (on("Target Health Bar") && c.crosshairTarget instanceof EntityHitResult' not in text:
    errors.append("Target health bar rendering is missing")
if 'if (on("Compass Strip"))' not in text or 'COMPASS  %s' not in text:
    errors.append("Compass strip rendering is missing")
if 'if (on("Target Health Percent")) targetLabel +=' not in text:
    errors.append("Target health percentage rendering is missing")
if any(term in text.lower() for term in ["nearby entity radar", "cachedradarentities", "nearby player count", "nearby entities", "nearby living entities"]):
    errors.append("Radar-related visuals or scan cache should be removed")
if 'if (on("Attack Cooldown Meter"))' not in text:
    errors.append("Attack cooldown meter rendering is missing")
if 'if (on("Ping Graph"))' not in text:
    errors.append("Ping graph rendering is missing")
if 'if (on("Block Reach Meter"))' not in text:
    errors.append("Block reach meter rendering is missing")
if 'if (on("Resource Alert Panel"))' not in text:
    errors.append("Resource alert panel rendering is missing")
if 'private static int countItem(' not in text:
    errors.append("Item counter helper is missing")
if 'Text.literal("Clear")' not in text:
    errors.append("Search clear button is missing")
if 'if (on("Armor Durability Bars"))' not in text:
    errors.append("Armor durability bars rendering is missing")
if "MC.player == null || MC.world == null || !on(\"Fullbright\")" not in text:
    errors.append("Fullbright must restore gamma when leaving a world or disabling the feature")
if "ClientLifecycleEvents.CLIENT_STOPPING.register(client -> { restoreGamma(); restoreViewBobbing(); })" not in text:
    errors.append("Gamma and View Bobbing restoration on client shutdown is missing")
if "private static void restoreViewBobbing()" not in text or "originalViewBobbing" not in text:
    errors.append("Original View Bobbing restoration is missing")
# Lightweight delimiter check after removing comments and string literals.
stripped = re.sub(r'//[^\n]*|/\*.*?\*/', '', text, flags=re.S)
stripped = re.sub(r'"(?:\\.|[^"\\])*"', '""', stripped)
for left, right, label in [('{', '}', 'braces'), ('(', ')', 'parentheses'), ('[', ']', 'brackets')]:
    balance = 0
    for char in stripped:
        if char == left:
            balance += 1
        elif char == right:
            balance -= 1
            if balance < 0:
                errors.append(f"Unbalanced {label}")
                break
    if balance != 0:
        errors.append(f"Unbalanced {label}: final balance {balance}")
if errors:
    print("SOURCE CHECK FAILED")
    print("\n".join("- " + e for e in errors))
    sys.exit(1)
print("SOURCE CHECK PASSED (static checks only; this does not compile Java)")
print(f"Features declared: {len(names)} ({len(set(names))} unique)")
print("Fabric manifest: valid JSON; client entrypoint present")
print("Language files: valid JSON (English and Russian)")
