@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ZEWS VISUALS - Build Minecraft 1.21.4
set "GRADLE_VERSION=8.10.2"
set "GRADLE_HOME_LOCAL=%LOCALAPPDATA%\ZEWS-VISUALS\gradle-%GRADLE_VERSION%"
set "GRADLE_EXE=%GRADLE_HOME_LOCAL%\bin\gradle.bat"
set "GRADLE_ZIP=%TEMP%\gradle-%GRADLE_VERSION%-bin.zip"
set "LOG_FILE=%~dp0build-log.txt"

echo ================================================
echo   ZEWS VISUALS - build for Minecraft 1.21.4
echo ================================================
echo.
where java >nul 2>nul
if errorlevel 1 goto NO_JAVA
where javac >nul 2>nul
if errorlevel 1 (
  echo ERROR: javac was not found. Install JDK 21, not only a Java runtime.
  goto FAILED
)
java -version 2>&1 | findstr /C:"21." >nul
if errorlevel 1 (
  echo ERROR: Java 21 was not detected. Install JDK 21 and rerun.
  goto FAILED
)
javac -version 2>&1 | findstr /C:"21." >nul
if errorlevel 1 (
  echo ERROR: javac 21 was not detected. Make sure JDK 21 is on PATH.
  goto FAILED
)

where gradle >nul 2>nul
if not errorlevel 1 (
  set "GRADLE_CMD=gradle"
  goto BUILD
)
if exist "%GRADLE_EXE%" (
  set "GRADLE_CMD=%GRADLE_EXE%"
  goto BUILD
)

echo Gradle was not found. Downloading Gradle %GRADLE_VERSION% automatically...
echo This requires an internet connection and may take several minutes.
if not exist "%LOCALAPPDATA%\ZEWS-VISUALS" mkdir "%LOCALAPPDATA%\ZEWS-VISUALS"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; try { Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_ZIP%' } catch { Write-Host $_; exit 1 }"
if errorlevel 1 (
  echo ERROR: Gradle download failed. Check internet access and try again.
  goto FAILED
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Expand-Archive -LiteralPath '%GRADLE_ZIP%' -DestinationPath '%LOCALAPPDATA%\ZEWS-VISUALS' -Force"
if errorlevel 1 (
  echo ERROR: Could not extract Gradle.
  goto FAILED
)
if not exist "%GRADLE_EXE%" (
  echo ERROR: Gradle was extracted but gradle.bat was not found.
  goto FAILED
)
set "GRADLE_CMD=%GRADLE_EXE%"

:BUILD
echo.
echo Running quick source checks if Python is installed...
where py >nul 2>nul
if not errorlevel 1 (
  py -3 "%~dp0tools\check_source.py"
  if errorlevel 1 (
    echo ERROR: Source sanity checks failed. Fix these issues before building.
    goto FAILED
  )
) else (
  echo Python launcher not found; skipping optional source checks.
)
echo.
echo Running Gradle build. Fabric/Minecraft dependencies will also be downloaded.
echo Full output is saved to build-log.txt.
call "%GRADLE_CMD%" --no-daemon clean build > "%LOG_FILE%" 2>&1
set "BUILD_EXIT=%ERRORLEVEL%"
type "%LOG_FILE%"
if not "%BUILD_EXIT%"=="0" (
  echo.
  echo BUILD FAILED. No successful JAR is confirmed.
  echo Send build-log.txt for diagnosis.
  goto FAILED
)
set "BUILT_JAR="
for /f "usebackq delims=" %%F in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$f=Get-ChildItem -LiteralPath '%~dp0build\libs' -Filter '*.jar' ^| Where-Object { $_.Name -notmatch '-sources\.jar$' } ^| Select-Object -First 1; if ($f) { $f.FullName }"`) do set "BUILT_JAR=%%F"
if not defined BUILT_JAR (
  echo ERROR: Gradle returned success, but no main JAR was found in build\libs.
  goto FAILED
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Add-Type -AssemblyName System.IO.Compression.FileSystem; $z=[IO.Compression.ZipFile]::OpenRead($env:BUILT_JAR); try { if (-not ($z.Entries ^| Where-Object { $_.FullName -eq 'fabric.mod.json' })) { throw 'fabric.mod.json missing from JAR' } } finally { $z.Dispose() }"
if errorlevel 1 (
  echo ERROR: JAR validation failed: fabric.mod.json is missing.
  goto FAILED
)
echo.
echo BUILD SUCCESSFUL. Main JAR was found and fabric.mod.json validated.
echo JAR: %BUILT_JAR%
copy /Y "%BUILT_JAR%" "%~dp0ZEWS-VISUALS-1.21.4.jar" >nul
if errorlevel 1 (
  echo WARNING: Could not copy the JAR beside this script. Use the path above.
) else (
  echo.
  echo Easy-to-find copy created:
  echo %~dp0ZEWS-VISUALS-1.21.4.jar
)
echo.
echo Install: copy the JAR into %%APPDATA%%\.minecraft\mods
if exist "%~dp0build\libs" explorer "%~dp0build\libs"
pause
exit /b 0

:NO_JAVA
echo ERROR: Java is not installed or is not on PATH. Install JDK 21 first.
:FAILED
echo.
echo Build did not complete. See the message above.
pause
exit /b 1
