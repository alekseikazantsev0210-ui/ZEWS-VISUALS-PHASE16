package com.zewsvisuals;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ZewsVisuals implements ClientModInitializer {
    private static final MinecraftClient MC = MinecraftClient.getInstance();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("zewsvisuals.json");
    private static final LinkedHashMap<String, Feature> FEATURES = new LinkedHashMap<>();
    private static KeyBinding menuKey;
    private static KeyBinding toggleHudKey;
    private static boolean customHudVisible = true;
    private static int lowHealthThreshold = 6;
    private static String activeProfile = "default";
    private static final Path ACTIVE_PROFILE_FILE = FabricLoader.getInstance().getConfigDir().resolve("zewsvisuals-profile.txt");
    private static final int[] CPS_HISTORY = new int[40];
    private static int cpsHistoryIndex = 0;
    private static long cpsWindowStart = System.currentTimeMillis();
    private static int leftClicks, rightClicks, shownLeftCps, shownRightCps;
    private static boolean previousLeft, previousRight;
    private static Boolean lastAppliedBobbing;
    private static Boolean originalViewBobbing;
    private static final long[] FPS_SAMPLES = new long[60];
    private static int fpsSampleIndex = 0;
    private static long lastHudNanos = 0L;
    private static int crosshairSize = 2;
    private static int accentColor = 0xFF55FFFF;
    private static float lastTrackedHealth = -1.0f;
    private static int damageFlashTicks = 0;
    private static final int[] PING_HISTORY = new int[40];
    private static int pingHistoryIndex = 0;
    private static int cachedPing = -1;
    private static int tickCounter = 0;
    private static float hudScale = 1.0f;
    private static int hudBackgroundOpacity = 72;
    private static int durabilityWarningPercent = 10;
    private static int crosshairGap = 4;
    private static int crosshairThickness = 2;
    private static Double originalGamma = null;
    private static boolean fullbrightApplied = false;
    private static TextFieldWidget redField, greenField, blueField;

    private static void add(String name, String category, boolean enabled) {
        FEATURES.put(name, new Feature(name, category, enabled));
    }

    static {
        Arrays.fill(PING_HISTORY, -1);
        add("Watermark", "HUD", true);
        add("FPS Counter", "HUD", true);
        add("Coordinates", "HUD", true);
        add("Direction", "HUD", true);
        add("Biome Name", "HUD", false);
        add("Clock", "HUD", false);
        add("Memory Usage", "HUD", false);
        add("Held Item", "HUD", false);
        add("Armor Status", "HUD", false);
        add("Potion Effects", "HUD", false);
        add("CPS Counter", "PvP HUD", true);
        add("Keystrokes", "PvP HUD", false);
        add("Sprint Status", "PvP HUD", false);
        add("Sneak Status", "PvP HUD", false);
        add("Crosshair Dot", "Visuals", false);
        add("Module List", "HUD", true);
        add("Low Health Warning", "HUD", false);
        add("View Bobbing", "Visuals", true);
        add("Show System Time", "HUD", false);
        add("Show Server Address", "HUD", false);
        add("Armor Durability", "HUD", false);
        add("Food Level", "HUD", false);
        add("Day Counter", "HUD", false);
        add("Chunk Coordinates", "HUD", false);
        add("Movement Speed", "HUD", false);
        add("Ping", "HUD", false);
        add("Light Level", "World", false);
        add("Target Block", "World", false);
        add("Held Item Durability", "HUD", false);
        add("Nether Coordinates", "World", false);
        add("Player Health", "HUD", false);
        add("Facing Angle", "HUD", false);
        add("Dimension", "HUD", false);
        add("Experience Status", "HUD", false);
        add("Target Name", "Target HUD", false);
        add("Target Health", "Target HUD", false);
        add("Target Distance", "Target HUD", false);
        add("Target Armor", "Target HUD", false);
        add("World Time Ticks", "HUD", false);
        add("FPS Graph", "HUD", false);
        add("Frame Time", "HUD", false);
        add("Memory Percentage", "HUD", false);
        add("Free Memory", "HUD", false);
        add("Block Position", "World", false);
        add("Compass Letters", "HUD", false);
        add("Durability Warning", "HUD", false);
        add("Potion Duration", "HUD", false);
        add("Totem Count", "PvP HUD", false);
        add("Golden Apple Count", "PvP HUD", false);
        add("Arrow Count", "PvP HUD", false);
        add("Armor Points", "HUD", false);
        add("Health Bar", "HUD", false);
        add("Hunger Warning", "HUD", false);
        add("Air Level", "HUD", false);
        add("Ground Status", "HUD", false);
        add("Movement State", "HUD", false);
        add("Precise Coordinates", "HUD", false);
        add("Mouse Keystrokes", "PvP HUD", false);
        add("CPS Graph", "PvP HUD", false);
        add("12 Hour Clock", "HUD", false);
        add("Potion Compact Mode", "HUD", false);
        add("Armor Icons", "HUD", false);
        add("Item Durability Bar", "HUD", false);
        add("HUD Visibility Hotkey", "HUD", false);
        add("Fullbright", "Visuals", false);
        add("Dynamic Crosshair", "Visuals", false);
        add("Crosshair Hit Color", "Visuals", false);
        add("HUD Text Background", "HUD", false);
        add("Target Health Bar", "Target HUD", false);
        add("Armor Durability Bars", "HUD", false);
        add("Compass Strip", "HUD", false);
        add("Target Health Percent", "Target HUD", false);
        add("Jump Status", "Movement HUD", false);
        add("Swimming Status", "Movement HUD", false);
        add("Experience Progress Bar", "HUD", false);
        add("Health Percentage", "HUD", false);
        add("Hunger Percentage", "HUD", false);
        add("Armor Durability Percent", "HUD", false);
        add("Target Entity Type", "Target HUD", false);
        add("Target Distance Exact", "Target HUD", false);
        add("Underwater Warning", "World", false);
        add("Combat Readiness Panel", "PvP HUD", false);
        add("Damage Flash Overlay", "Visuals", false);
        add("Attack Cooldown Meter", "PvP HUD", false);
        add("Potion Timeline", "HUD", false);
        add("Armor Loadout Panel", "HUD", false);
        add("Fall Distance Meter", "Movement HUD", false);
        add("Hotbar Item Spotlight", "HUD", false);
        add("Weather & Time Card", "World", false);
        add("Low Health Vignette", "Visuals", false);
        add("Ping Graph", "HUD", false);
        add("Block Reach Meter", "World", false);
        add("Velocity Vector", "Movement HUD", false);
        add("Resource Alert Panel", "PvP HUD", false);
        add("Biome & Dimension Card", "World", false);
        add("Inventory Durability Scan", "HUD", false);
        add("Status Effect Count", "HUD", false);
        add("Air Safety Meter", "Movement HUD", false);
    }

    private static Path configFile() {
        if ("default".equals(activeProfile)) return CONFIG;
        return CONFIG.resolveSibling("zewsvisuals_" + activeProfile + ".json");
    }

    @Override public void onInitializeClient() {
        loadConfig();
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.zewsvisuals.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
            "key.category.zewsvisuals"));
        toggleHudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.zewsvisuals.toggle_hud", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F8,
            "key.category.zewsvisuals"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) client.setScreen(new FeatureScreen());
            while (toggleHudKey.wasPressed()) if (on("HUD Visibility Hotkey")) customHudVisible = !customHudVisible;
            updateClicks();
            if (client.player != null) {
                float currentHealth = client.player.getHealth();
                if (lastTrackedHealth >= 0.0f && currentHealth < lastTrackedHealth) damageFlashTicks = 12;
                else if (damageFlashTicks > 0) damageFlashTicks--;
                lastTrackedHealth = currentHealth;
            } else {
                lastTrackedHealth = -1.0f;
                damageFlashTicks = 0;
            }
            if (++tickCounter % 10 == 0) {
                var network = client.getNetworkHandler();
                var entry = client.player == null || network == null ? null : network.getPlayerListEntry(client.player.getUuid());
                cachedPing = entry == null ? -1 : entry.getLatency();
                PING_HISTORY[pingHistoryIndex] = cachedPing;
                pingHistoryIndex = (pingHistoryIndex + 1) % PING_HISTORY.length;
            }
            applyOptions();
        });
        HudRenderCallback.EVENT.register((draw, tickCounter) -> renderHud(draw));
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> { restoreGamma(); restoreViewBobbing(); });
    }

    private static void updateClicks() {
        if (MC.getWindow() == null) return;
        long handle = MC.getWindow().getHandle();
        boolean left = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean right = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        // Count clicks only while the player is actively in-world, not in menus/screens.
        if (MC.player != null && MC.currentScreen == null) {
            if (left && !previousLeft) leftClicks++;
            if (right && !previousRight) rightClicks++;
        }
        previousLeft = left;
        previousRight = right;
        long now = System.currentTimeMillis();
        if (now - cpsWindowStart >= 1000) {
            shownLeftCps = leftClicks;
            shownRightCps = rightClicks;
            CPS_HISTORY[cpsHistoryIndex] = Math.min(20, leftClicks + rightClicks);
            cpsHistoryIndex = (cpsHistoryIndex + 1) % CPS_HISTORY.length;
            leftClicks = rightClicks = 0;
            cpsWindowStart = now;
        }
    }

    private static void applyOptions() {
        if (MC.options == null) return;
        Feature bobbing = FEATURES.get("View Bobbing");
        if (bobbing != null) {
            if (originalViewBobbing == null) originalViewBobbing = MC.options.getViewBobbing().getValue();
            if (lastAppliedBobbing == null || lastAppliedBobbing != bobbing.enabled) {
                MC.options.getViewBobbing().setValue(bobbing.enabled);
                lastAppliedBobbing = bobbing.enabled;
            }
        }
        // Do not leave modified gamma behind on the title screen or while disconnected.
        // Re-capture the user's current value the next time a world is entered.
        if (MC.player == null || MC.world == null || !on("Fullbright")) {
            restoreGamma();
            return;
        }
        // Fullbright uses vanilla gamma and restores the exact previous value when disabled.
        if (!fullbrightApplied) {
            originalGamma = MC.options.getGamma().getValue();
            fullbrightApplied = true;
        }
        MC.options.getGamma().setValue(16.0);
    }

    private static void restoreGamma() {
        if (fullbrightApplied && originalGamma != null && MC.options != null) {
            MC.options.getGamma().setValue(originalGamma);
        }
        fullbrightApplied = false;
        originalGamma = null;
    }

    private static void restoreViewBobbing() {
        if (originalViewBobbing != null && MC.options != null) {
            MC.options.getViewBobbing().setValue(originalViewBobbing);
        }
        originalViewBobbing = null;
        lastAppliedBobbing = null;
    }

    private static void renderHud(DrawContext draw) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden || !customHudVisible) return;
        long nowNanos = System.nanoTime();
        if (lastHudNanos != 0L) {
            FPS_SAMPLES[fpsSampleIndex] = Math.max(0L, nowNanos - lastHudNanos);
            fpsSampleIndex = (fpsSampleIndex + 1) % FPS_SAMPLES.length;
        }
        lastHudNanos = nowNanos;

        // Scale around screen center so the setting affects the complete custom HUD.
        draw.getMatrices().push();
        float scale = Math.max(0.65f, Math.min(1.5f, hudScale));
        float centerX = c.getWindow().getScaledWidth() / 2.0f;
        float centerY = c.getWindow().getScaledHeight() / 2.0f;
        draw.getMatrices().translate(centerX, centerY, 0.0f);
        draw.getMatrices().scale(scale, scale, 1.0f);
        draw.getMatrices().translate(-centerX, -centerY, 0.0f);

        int y = 7;
        if (on("Watermark")) {
            drawHudText(draw, c, Text.literal("ZEWS VISUALS").formatted(Formatting.AQUA, Formatting.BOLD), 7, y, 0x55FFFF);
            y += 12;
        }
        if (on("FPS Counter")) {
            drawHudText(draw, c, "FPS: " + c.getCurrentFps(), 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Coordinates")) {
            drawHudText(draw, c,
                on("Precise Coordinates") ? String.format(Locale.ROOT, "XYZ: %.3f / %.3f / %.3f", c.player.getX(), c.player.getY(), c.player.getZ()) : String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f", c.player.getX(), c.player.getY(), c.player.getZ()), 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Direction")) {
            drawHudText(draw, c, "Facing: " + c.player.getHorizontalFacing().asString().toUpperCase(Locale.ROOT), 7, y, 0x55FFFF); y += 11;
        }
        if (on("Compass Strip")) {
            int compassY = 38;
            int center = c.getWindow().getScaledWidth() / 2;
            String facing = c.player.getHorizontalFacing().asString().toUpperCase(Locale.ROOT);
            float yaw = c.player.getYaw() % 360.0f;
            if (yaw < 0) yaw += 360.0f;
            String heading = String.format(Locale.ROOT, "COMPASS  %s  •  %.0f°", facing, yaw);
            int compassWidth = c.textRenderer.getWidth(heading) + 14;
            draw.fill(center - compassWidth / 2, compassY - 3, center + compassWidth / 2, compassY + 11, 0x88000000);
            draw.drawCenteredTextWithShadow(c.textRenderer, Text.literal(heading).formatted(Formatting.AQUA, Formatting.BOLD), center, compassY, accentColor);
        }
        if (on("Biome Name")) {
            String biome = c.world.getBiome(c.player.getBlockPos()).getKey().map(k -> k.getValue().toString()).orElse("unknown");
            drawHudText(draw, c, "Biome: " + biome, 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Clock")) {
            drawHudText(draw, c, "Time: " + String.format(Locale.ROOT, "%02d:%02d", (c.world.getTimeOfDay() / 1000 + 6) % 24, (c.world.getTimeOfDay() % 1000) * 60 / 1000), 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Show System Time")) {
            drawHudText(draw, c, "Local: " + LocalTime.now().format(DateTimeFormatter.ofPattern(on("12 Hour Clock") ? "hh:mm:ss a" : "HH:mm:ss", Locale.ROOT)), 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Day Counter")) {
            drawHudText(draw, c, "Day: " + (c.world.getTime() / 24000L + 1), 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Chunk Coordinates")) {
            drawHudText(draw, c, "Chunk: " + c.player.getChunkPos().x + ", " + c.player.getChunkPos().z, 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Movement Speed")) {
            double speed = Math.sqrt(c.player.getVelocity().x * c.player.getVelocity().x + c.player.getVelocity().z * c.player.getVelocity().z) * 20.0;
            drawHudText(draw, c, String.format(Locale.ROOT, "Speed: %.2f blocks/s", speed), 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Food Level")) {
            drawHudText(draw, c, "Food: " + c.player.getHungerManager().getFoodLevel() + "/20", 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Armor Durability")) {
            StringBuilder durability = new StringBuilder("Durability: ");
            boolean found = false;
            for (ItemStack stack : c.player.getArmorItems()) {
                if (!stack.isEmpty() && stack.isDamageable()) {
                    if (found) durability.append(" | ");
                    durability.append(stack.getName().getString()).append(" ")
                        .append(Math.max(0, stack.getMaxDamage() - stack.getDamage())).append("/").append(stack.getMaxDamage());
                    found = true;
                }
            }
            drawHudText(draw, c, found ? durability.toString() : "Durability: no damaged armor items", 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Ping")) {
            var network = c.getNetworkHandler();
            var entry = network == null ? null : network.getPlayerListEntry(c.player.getUuid());
            drawHudText(draw, c, "Ping: " + (entry == null ? "--" : entry.getLatency() + " ms"), 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Light Level")) {
            drawHudText(draw, c, "Light: " + c.world.getLightLevel(c.player.getBlockPos()), 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Target Block")) {
            if (c.crosshairTarget != null && c.crosshairTarget.getType() == HitResult.Type.BLOCK) {
                BlockPos targetPos = ((BlockHitResult)c.crosshairTarget).getBlockPos();
                String targetName = c.world.getBlockState(targetPos).getBlock().getName().getString();
                drawHudText(draw, c, "Block: " + targetName + " @ " + targetPos.getX() + " " + targetPos.getY() + " " + targetPos.getZ(), 7, y, 0xFFFFFF); y += 11;
            } else {
                drawHudText(draw, c, "Block: none", 7, y, 0xAAAAAA); y += 11;
            }
        }
        if (on("Held Item Durability")) {
            ItemStack held = c.player.getMainHandStack();
            String value = held.isEmpty() ? "empty" : (held.isDamageable() ? Math.max(0, held.getMaxDamage() - held.getDamage()) + "/" + held.getMaxDamage() : "unbreakable");
            drawHudText(draw, c, "Item durability: " + value, 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Nether Coordinates")) {
            String dim = c.world.getRegistryKey().getValue().toString();
            if (dim.equals("minecraft:overworld")) {
                drawHudText(draw, c, String.format(Locale.ROOT, "Nether: %.1f, %.1f", c.player.getX() / 8.0, c.player.getZ() / 8.0), 7, y, 0xFFAA55); y += 11;
            } else if (dim.equals("minecraft:the_nether")) {
                drawHudText(draw, c, String.format(Locale.ROOT, "Overworld: %.1f, %.1f", c.player.getX() * 8.0, c.player.getZ() * 8.0), 7, y, 0xFFAA55); y += 11;
            } else {
                drawHudText(draw, c, "Nether coords: N/A", 7, y, 0xAAAAAA); y += 11;
            }
        }
        if (on("Player Health")) {
            drawHudText(draw, c, String.format(Locale.ROOT, "Health: %.1f/%.1f", c.player.getHealth(), c.player.getMaxHealth()), 7, y, c.player.getHealth() <= 6 ? 0xFFFF5555 : 0xFFFFFF); y += 11;
        }
        if (on("Facing Angle")) {
            drawHudText(draw, c, String.format(Locale.ROOT, "Yaw/Pitch: %.1f° / %.1f°", c.player.getYaw(), c.player.getPitch()), 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Dimension")) {
            drawHudText(draw, c, "Dimension: " + c.world.getRegistryKey().getValue(), 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Experience Status")) {
            drawHudText(draw, c, String.format(Locale.ROOT, "XP: level %d • %.0f%%", c.player.experienceLevel, c.player.experienceProgress * 100.0f), 7, y, 0x55FF55); y += 11;
        }
        if (on("Jump Status")) {
            String jump = c.player.isOnGround() ? "READY" : (c.player.getVelocity().y > 0.08 ? "RISING" : c.player.getVelocity().y < -0.08 ? "FALLING" : "AIRBORNE");
            drawHudText(draw, c, "Jump: " + jump, 7, y, jump.equals("RISING") ? 0xFF55FF77 : accentColor); y += 11;
        }
        if (on("Swimming Status")) {
            String swim = c.player.isSubmergedInWater() ? "UNDERWATER" : c.player.isTouchingWater() ? "IN WATER" : c.player.isInLava() ? "IN LAVA" : c.player.isSwimming() ? "SWIMMING" : "DRY";
            int swimColor = (c.player.isSubmergedInWater() || c.player.isInLava()) ? 0xFFFF6655 : accentColor;
            drawHudText(draw, c, "Environment: " + swim, 7, y, swimColor); y += 11;
        }
        if (on("Experience Progress Bar")) {
            int bx = 7, by = y + 2, bw = 110;
            draw.fill(bx, by, bx + bw, by + 6, 0xAA222222);
            int fill = (int)(bw * Math.max(0.0f, Math.min(1.0f, c.player.experienceProgress)));
            draw.fill(bx, by, bx + fill, by + 6, 0xFF55FF55);
            drawHudText(draw, c, "XP L" + c.player.experienceLevel + " " + Math.round(c.player.experienceProgress * 100) + "%", bx + bw + 5, by - 3, 0xFFFFFFFF); y += 12;
        }
        if (on("Health Percentage")) {
            int pct = (int)Math.round(100.0 * c.player.getHealth() / Math.max(1.0f, c.player.getMaxHealth()));
            drawHudText(draw, c, "Health: " + pct + "%", 7, y, pct <= 30 ? 0xFFFF5555 : 0xFF55FF77); y += 11;
        }
        if (on("Hunger Percentage")) {
            int food = c.player.getHungerManager().getFoodLevel();
            drawHudText(draw, c, "Hunger: " + (food * 5) + "%", 7, y, food <= 6 ? 0xFFFFAA33 : 0xFFFFFFFF); y += 11;
        }
        if (on("Armor Durability Percent")) {
            int total = 0, remaining = 0, pieces = 0;
            for (ItemStack armor : c.player.getArmorItems()) {
                if (!armor.isEmpty() && armor.isDamageable()) { total += armor.getMaxDamage(); remaining += Math.max(0, armor.getMaxDamage() - armor.getDamage()); pieces++; }
            }
            String armorPct = pieces == 0 || total == 0 ? "N/A" : Math.round(remaining * 100.0 / total) + "%";
            drawHudText(draw, c, "Armor durability: " + armorPct, 7, y, pieces > 0 && remaining * 100L < total * 20L ? 0xFFFF6655 : 0xFFFFFFFF); y += 11;
        }
        if (on("Underwater Warning") && c.player.isSubmergedInWater()) {
            int airSeconds = Math.max(0, c.player.getAir()) / 20;
            drawHudText(draw, c, "UNDERWATER · air ~" + airSeconds + "s", 7, y, airSeconds <= 3 ? 0xFFFF4444 : 0xFF55FFFF); y += 11;
        }
        if (on("Target Name") || on("Target Health") || on("Target Distance") || on("Target Armor") || on("Target Entity Type") || on("Target Distance Exact")) {
            if (c.crosshairTarget instanceof EntityHitResult entityHit && entityHit.getEntity() instanceof LivingEntity target) {
                if (on("Target Name")) { drawHudText(draw, c, "Target: " + target.getName().getString(), 7, y, accentColor); y += 11; }
                if (on("Target Health")) { drawHudText(draw, c, String.format(Locale.ROOT, "Target HP: %.1f/%.1f", target.getHealth(), target.getMaxHealth()), 7, y, target.getHealth() <= 6 ? 0xFFFF5555 : 0xFFFFFFFF); y += 11; }
                if (on("Target Distance")) { drawHudText(draw, c, String.format(Locale.ROOT, "Target distance: %.1f m", c.player.getPos().distanceTo(target.getPos())), 7, y, 0xFFFFFFFF); y += 11; }
                if (on("Target Armor")) { drawHudText(draw, c, "Target armor: " + target.getArmor(), 7, y, 0xFFFFFFFF); y += 11; }
                if (on("Target Entity Type")) { drawHudText(draw, c, "Target type: " + target.getType().getName().getString(), 7, y, accentColor); y += 11; }
                if (on("Target Distance Exact")) { drawHudText(draw, c, String.format(Locale.ROOT, "Exact range: %.2f blocks", c.player.getPos().distanceTo(target.getPos())), 7, y, 0xFFFFFFFF); y += 11; }
            } else if (on("Target Name")) { drawHudText(draw, c, "Target: none", 7, y, 0xFFAAAAAA); y += 11; }
        }
        if (on("World Time Ticks")) { drawHudText(draw, c, "World ticks: " + c.world.getTime(), 7, y, 0xFFFFFFFF); y += 11; }
        if (on("Frame Time")) {
            long frameMs = FPS_SAMPLES[(fpsSampleIndex + FPS_SAMPLES.length - 1) % FPS_SAMPLES.length] / 1_000_000L;
            drawHudText(draw, c, "Frame: " + frameMs + " ms", 7, y, 0xFFFFFFFF); y += 11;
        }
        if (on("FPS Graph")) {
            int gx = 7, gy = y + 34;
            draw.fill(gx - 2, gy - 34, gx + FPS_SAMPLES.length * 2 + 2, gy + 2, 0x55000000);
            for (int i = 0; i < FPS_SAMPLES.length; i++) {
                long ns = FPS_SAMPLES[(fpsSampleIndex + i) % FPS_SAMPLES.length];
                int ms = (int)Math.min(34, ns / 1_000_000L);
                draw.fill(gx + i * 2, gy - ms, gx + i * 2 + 1, gy, ms > 25 ? 0xFFFF5555 : accentColor);
            }
            y += 42;
        }
        if (on("Memory Percentage") || on("Free Memory")) {
            Runtime r = Runtime.getRuntime();
            long used = r.totalMemory() - r.freeMemory(), max = r.maxMemory();
            if (on("Memory Percentage")) { drawHudText(draw, c, String.format(Locale.ROOT, "Memory used: %.1f%%", max == 0 ? 0 : used * 100.0 / max), 7, y, 0xFFFFFFFF); y += 11; }
            if (on("Free Memory")) { drawHudText(draw, c, "Memory free: " + ((max - used) / 1048576) + " MB", 7, y, 0xFFFFFFFF); y += 11; }
        }
        if (on("Block Position")) { BlockPos bp = c.player.getBlockPos(); drawHudText(draw, c, "Block: " + bp.getX() + ", " + bp.getY() + ", " + bp.getZ(), 7, y, 0xFFFFFFFF); y += 11; }
        if (on("Compass Letters")) { drawHudText(draw, c, "Compass: " + c.player.getHorizontalFacing().asString().toUpperCase(Locale.ROOT), 7, y, accentColor); y += 11; }
        if (on("Durability Warning")) {
            for (ItemStack stack : c.player.getInventory().main) {
                if (!stack.isEmpty() && stack.isDamageable()) {
                    int remaining = stack.getMaxDamage() - stack.getDamage();
                    if (remaining <= Math.max(1, stack.getMaxDamage() * durabilityWarningPercent / 100)) {
                        drawHudText(draw, c, "LOW DURABILITY: " + stack.getName().getString() + " (" + remaining + ")", 7, y, 0xFFFF5555); y += 11;
                        break;
                    }
                }
            }
        }
        if (on("Potion Duration")) {
            for (StatusEffectInstance effect : c.player.getStatusEffects()) {
                int ticks = effect.getDuration();
                String duration = ticks < 0 ? "∞" : String.format(Locale.ROOT, "%d:%02d", ticks / 1200, (ticks / 20) % 60);
                drawHudText(draw, c, effect.getEffectType().value().getName().getString() + " " + duration, 7, y, accentColor); y += 10;
                if (y > c.getWindow().getScaledHeight() - 25) break;
            }
        }
        if (on("Totem Count")) { drawHudText(draw, c, "Totems: " + c.player.getInventory().count(Items.TOTEM_OF_UNDYING), 7, y, 0xFFFFFFFF); y += 11; }
        if (on("Golden Apple Count")) { drawHudText(draw, c, "Golden apples: " + (c.player.getInventory().count(Items.GOLDEN_APPLE) + c.player.getInventory().count(Items.ENCHANTED_GOLDEN_APPLE)), 7, y, 0xFFFFFFFF); y += 11; }
        if (on("Arrow Count")) {
            int arrows = c.player.getInventory().count(Items.ARROW) + c.player.getInventory().count(Items.SPECTRAL_ARROW) + c.player.getInventory().count(Items.TIPPED_ARROW);
            drawHudText(draw, c, "Arrows: " + arrows, 7, y, 0xFFFFFFFF); y += 11;
        }
        if (on("Armor Points")) { drawHudText(draw, c, "Armor points: " + c.player.getArmor() + "/20", 7, y, 0xFFFFFFFF); y += 11; }
        if (on("Health Bar")) {
            int bx = 7, by = y + 2, bw = 100;
            draw.fill(bx, by, bx + bw, by + 7, 0xAA222222);
            int fill = (int)(bw * Math.max(0, Math.min(1, c.player.getHealth() / Math.max(1, c.player.getMaxHealth()))));
            draw.fill(bx, by, bx + fill, by + 7, c.player.getHealth() <= 6 ? 0xFFFF4444 : 0xFF55FF77);
            drawHudText(draw, c, String.format(Locale.ROOT, "HP %.1f", c.player.getHealth()), bx + bw + 5, by - 2, 0xFFFFFFFF); y += 13;
        }
        if (on("Hunger Warning") && c.player.getHungerManager().getFoodLevel() <= 6) { drawHudText(draw, c, "LOW HUNGER!", 7, y, 0xFFFFAA33); y += 11; }
        if (on("Air Level")) { drawHudText(draw, c, "Air: " + c.player.getAir() + "/" + c.player.getMaxAir(), 7, y, c.player.getAir() < 60 ? 0xFFFF5555 : 0xFFFFFFFF); y += 11; }
        if (on("Ground Status")) { drawHudText(draw, c, "On ground: " + (c.player.isOnGround() ? "YES" : "NO"), 7, y, 0xFFFFFFFF); y += 11; }
        if (on("Movement State")) {
            String state = c.player.isGliding() ? "Gliding" : c.player.isSwimming() ? "Swimming" : c.player.isClimbing() ? "Climbing" : c.player.isSprinting() ? "Sprinting" : c.player.isSneaking() ? "Sneaking" : c.player.isOnGround() ? "Walking/Idle" : "Falling";
            drawHudText(draw, c, "Movement: " + state, 7, y, accentColor); y += 11;
        }
        if (on("Memory Usage")) {
            Runtime r = Runtime.getRuntime();
            long used = (r.totalMemory() - r.freeMemory()) / 1048576;
            long max = r.maxMemory() / 1048576;
            drawHudText(draw, c, "Memory: " + used + "/" + max + " MB", 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Held Item")) {
            ItemStack stack = c.player.getMainHandStack();
            drawHudText(draw, c, "Held: " + (stack.isEmpty() ? "Empty" : stack.getName().getString()), 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Armor Status")) {
            StringBuilder armor = new StringBuilder("Armor: ");
            for (ItemStack stack : c.player.getArmorItems()) {
                if (!stack.isEmpty()) armor.append(stack.getName().getString()).append(" ");
            }
            drawHudText(draw, c, armor.toString(), 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Potion Effects")) {
            if (on("Potion Compact Mode")) {
                StringJoiner effects = new StringJoiner(" | ");
                for (StatusEffectInstance effect : c.player.getStatusEffects()) effects.add(effect.getEffectType().value().getName().getString() + " " + (effect.getAmplifier() + 1));
                if (effects.length() > 0) { drawHudText(draw, c, effects.toString(), 7, y, accentColor); y += 11; }
            } else {
                for (StatusEffectInstance effect : c.player.getStatusEffects()) {
                    String label = effect.getEffectType().value().getName().getString() + " " + (effect.getAmplifier() + 1);
                    drawHudText(draw, c, label, 7, y, 0x55FFFF); y += 10;
                    if (y > c.getWindow().getScaledHeight() - 25) break;
                }
            }
        }
        if (on("CPS Counter")) {
            drawHudText(draw, c, "CPS  L " + shownLeftCps + "  R " + shownRightCps, 7, y, 0xFFFFFF); y += 11;
        }
        if (on("Keystrokes")) {
            int ky = c.getWindow().getScaledHeight() - 48;
            String keys = key(c.options.forwardKey) + " " + key(c.options.leftKey) + " " + key(c.options.backKey) + " " + key(c.options.rightKey);
            drawHudText(draw, c, keys, 8, ky, 0x55FFFF);
            drawHudText(draw, c, key(c.options.jumpKey) + "  " + key(c.options.sprintKey), 8, ky + 11, 0x55FFFF);
        }
        if (on("Mouse Keystrokes")) {
            long handle = c.getWindow().getHandle();
            String mouse = (GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS ? "[LMB]" : "LMB") + "  " +
                (GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS ? "[RMB]" : "RMB");
            drawHudText(draw, c, mouse, 8, c.getWindow().getScaledHeight() - 24, accentColor);
        }
        if (on("CPS Graph")) {
            int gx = 7, gy = c.getWindow().getScaledHeight() - 36;
            draw.fill(gx - 2, gy - 24, gx + CPS_HISTORY.length * 3 + 2, gy + 2, 0x55000000);
            for (int i = 0; i < CPS_HISTORY.length; i++) {
                int value = CPS_HISTORY[(cpsHistoryIndex + i) % CPS_HISTORY.length];
                draw.fill(gx + i * 3, gy - value, gx + i * 3 + 2, gy, accentColor);
            }
        }
        if (on("Armor Icons")) {
            int ax = c.getWindow().getScaledWidth() - 20;
            int ay = c.getWindow().getScaledHeight() / 2 - 36;
            for (ItemStack armorStack : c.player.getArmorItems()) {
                if (!armorStack.isEmpty()) { draw.drawItem(armorStack, ax, ay); ay += 18; }
            }
        }
        if (on("Item Durability Bar")) {
            ItemStack heldForBar = c.player.getMainHandStack();
            if (!heldForBar.isEmpty() && heldForBar.isDamageable()) {
                int maxDamage = Math.max(1, heldForBar.getMaxDamage());
                int remaining = Math.max(0, maxDamage - heldForBar.getDamage());
                int bx = 7, by = c.getWindow().getScaledHeight() - 14, bw = 80;
                draw.fill(bx, by, bx + bw, by + 5, 0xAA222222);
                int fill = (int)(bw * remaining / (double)maxDamage);
                int color = remaining * 5 < maxDamage ? 0xFFFF4444 : remaining * 2 < maxDamage ? 0xFFFFAA33 : 0xFF55FF77;
                draw.fill(bx, by, bx + fill, by + 5, color);
            }
        }
        if (on("Armor Durability Bars")) {
            int barX = c.getWindow().getScaledWidth() - 92;
            int barY = c.getWindow().getScaledHeight() / 2 - 34;
            for (ItemStack armorStack : c.player.getArmorItems()) {
                if (!armorStack.isEmpty() && armorStack.isDamageable()) {
                    int maxDamage = Math.max(1, armorStack.getMaxDamage());
                    int remaining = Math.max(0, maxDamage - armorStack.getDamage());
                    int percent = (int)Math.round(remaining * 100.0 / maxDamage);
                    int fill = 54 * remaining / maxDamage;
                    int color = percent <= durabilityWarningPercent ? 0xFFFF4444 : percent <= 35 ? 0xFFFFAA33 : 0xFF55FF77;
                    draw.drawItem(armorStack, barX, barY - 2);
                    draw.fill(barX + 20, barY + 4, barX + 74, barY + 8, 0xAA222222);
                    draw.fill(barX + 20, barY + 4, barX + 20 + fill, barY + 8, color);
                    draw.drawTextWithShadow(c.textRenderer, percent + "%", barX + 20, barY - 7, 0xFFFFFFFF);
                    barY += 20;
                }
            }
        }
        if (on("Target Health Bar") && c.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity target) {
            int barWidth = 120;
            int barX = (c.getWindow().getScaledWidth() - barWidth) / 2;
            int barY = c.getWindow().getScaledHeight() / 2 + 28;
            float maxHealth = Math.max(1.0f, target.getMaxHealth());
            float health = Math.max(0.0f, Math.min(maxHealth, target.getHealth()));
            int fill = Math.round(barWidth * health / maxHealth);
            int color = health / maxHealth <= 0.25f ? 0xFFFF4444 : health / maxHealth <= 0.5f ? 0xFFFFAA33 : 0xFF55FF77;
            draw.fill(barX - 1, barY - 1, barX + barWidth + 1, barY + 7, 0xCC111111);
            draw.fill(barX, barY, barX + barWidth, barY + 5, 0xFF552222);
            draw.fill(barX, barY, barX + fill, barY + 5, color);
            int healthPercent = Math.round(100.0f * health / maxHealth);
            String targetLabel = target.getName().getString() + "  " + String.format(Locale.ROOT, "%.1f/%.1f HP", health, maxHealth);
            if (on("Target Health Percent")) targetLabel += "  (" + healthPercent + "%)";
            draw.drawCenteredTextWithShadow(c.textRenderer, targetLabel, c.getWindow().getScaledWidth() / 2, barY - 13, 0xFFFFFFFF);
        }
        if (on("Low Health Warning") && c.player.getHealth() <= lowHealthThreshold)
            drawHudText(draw, c, "LOW HEALTH!", c.getWindow().getScaledWidth() / 2 - c.textRenderer.getWidth("LOW HEALTH!") / 2, 12, 0xFFFF5555);
        if (on("Sprint Status")) drawHudText(draw, c, "Sprint: " + (c.player.isSprinting() ? "ON" : "OFF"), 7, y, 0xFFFFFF);
        if (on("Sneak Status")) drawHudText(draw, c, "Sneak: " + (c.player.isSneaking() ? "ON" : "OFF"), 7, y + 11, 0xFFFFFF);
        if (on("Show Server Address") && c.getCurrentServerEntry() != null)
            drawHudText(draw, c, "Server: " + c.getCurrentServerEntry().address, 7, c.getWindow().getScaledHeight() - 12, 0xFFFFFF);

        if (on("Combat Readiness Panel")) {
            int px = 8, py = c.getWindow().getScaledHeight() - 78, pw = 118, ph = 66;
            draw.fill(px - 3, py - 3, px + pw, py + ph, 0xB80A1016);
            draw.fill(px - 3, py - 3, px + pw, py - 1, accentColor);
            int healthPct = Math.round(100.0f * c.player.getHealth() / Math.max(1.0f, c.player.getMaxHealth()));
            drawHudText(draw, c, "COMBAT STATUS", px, py + 2, accentColor);
            drawHudText(draw, c, "HP " + healthPct + "%  ARM " + c.player.getArmor(), px, py + 15, healthPct <= 30 ? 0xFFFF5555 : 0xFFFFFFFF);
            drawHudText(draw, c, "FOOD " + c.player.getHungerManager().getFoodLevel() + "/20", px, py + 27, 0xFFFFFFFF);
            drawHudText(draw, c, "TARGET " + (c.crosshairTarget instanceof EntityHitResult ? "LOCKED" : "—"), px, py + 39, c.crosshairTarget instanceof EntityHitResult ? 0xFF55FF77 : 0xFFAAAAAA);
            drawHudText(draw, c, "TOTEMS " + countItem(Items.TOTEM_OF_UNDYING), px, py + 51, 0xFFFFD166);
        }

        if (on("Damage Flash Overlay") && damageFlashTicks > 0) {
            int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
            int alpha = Math.min(150, damageFlashTicks * 12);
            int edge = (alpha << 24) | 0x00FF2233;
            draw.fill(0, 0, sw, 3, edge); draw.fill(0, sh - 3, sw, sh, edge);
            draw.fill(0, 0, 3, sh, edge); draw.fill(sw - 3, 0, sw, sh, edge);
        }
        if (on("Attack Cooldown Meter")) {
            int cx = c.getWindow().getScaledWidth() / 2, by = c.getWindow().getScaledHeight() / 2 + 20, bw = 70;
            float cooldown = c.player.getAttackCooldownProgress(0.0f);
            int fill = Math.round(bw * Math.max(0.0f, Math.min(1.0f, cooldown)));
            draw.fill(cx - bw / 2 - 1, by - 1, cx + bw / 2 + 1, by + 5, 0xCC080808);
            draw.fill(cx - bw / 2, by, cx + bw / 2, by + 3, 0xFF333333);
            draw.fill(cx - bw / 2, by, cx - bw / 2 + fill, by + 3, cooldown >= 0.99f ? 0xFFB7FF3C : 0xFF3CF5D5);
            draw.drawCenteredTextWithShadow(c.textRenderer, cooldown >= 0.99f ? "READY" : "CHARGING", cx, by + 7, cooldown >= 0.99f ? 0xFFB7FF3C : 0xFFAAAAAA);
        }
        if (on("Potion Timeline")) {
            int tx = c.getWindow().getScaledWidth() / 2 + 54, ty = 8, shown = 0;
            for (StatusEffectInstance effect : c.player.getStatusEffects()) {
                if (shown >= 5) break;
                int remaining = effect.getDuration();
                int barWidth = remaining < 0 ? 64 : Math.max(2, Math.min(64, remaining * 64 / 2400));
                String effectName = effect.getEffectType().value().getName().getString();
                String time = remaining < 0 ? "∞" : String.format(Locale.ROOT, "%d:%02d", remaining / 1200, (remaining / 20) % 60);
                draw.fill(tx - 3, ty - 2, tx + 70, ty + 19, 0xAA080B10);
                drawHudText(draw, c, effectName + " " + time, tx, ty, 0xFFFFFFFF);
                draw.fill(tx, ty + 11, tx + 64, ty + 14, 0xFF333333);
                draw.fill(tx, ty + 11, tx + barWidth, ty + 14, accentColor);
                ty += 23; shown++;
            }
        }
        if (on("Armor Loadout Panel")) {
            int ax = c.getWindow().getScaledWidth() / 2 - 48, ay = c.getWindow().getScaledHeight() - 58;
            draw.fill(ax - 5, ay - 5, ax + 101, ay + 28, 0xAA080B10);
            int slot = 0;
            for (ItemStack armor : c.player.getArmorItems()) {
                int sx = ax + slot * 25;
                if (!armor.isEmpty()) {
                    draw.drawItem(armor, sx, ay);
                    if (armor.isDamageable()) {
                        int max = Math.max(1, armor.getMaxDamage());
                        int remaining = Math.max(0, max - armor.getDamage());
                        int color = remaining * 100 / max <= durabilityWarningPercent ? 0xFFFF4444 : 0xFFB7FF3C;
                        draw.fill(sx, ay + 17, sx + 18, ay + 20, 0xFF333333);
                        draw.fill(sx, ay + 17, sx + 18 * remaining / max, ay + 20, color);
                    }
                }
                slot++;
            }
            draw.drawTextWithShadow(c.textRenderer, "ARMOR", ax + 2, ay - 3, accentColor);
        }
        if (on("Fall Distance Meter")) {
            float fall = c.player.fallDistance;
            int fx = c.getWindow().getScaledWidth() / 2 + 55, fy = c.getWindow().getScaledHeight() / 2 + 35;
            int color = fall >= 6.0f ? 0xFFFF5555 : fall >= 3.0f ? 0xFFFFBB55 : 0xFFB7FF3C;
            drawHudText(draw, c, String.format(Locale.ROOT, "FALL %.1fm", fall), fx, fy, color);
            if (fall >= 3.0f) draw.fill(fx, fy + 10, fx + Math.min(70, (int)(fall * 7)), fy + 12, color);
        }
        if (on("Hotbar Item Spotlight")) {
            ItemStack selected = c.player.getMainHandStack();
            if (!selected.isEmpty()) {
                int hx = c.getWindow().getScaledWidth() / 2, hy = c.getWindow().getScaledHeight() - 39;
                String itemName = selected.getName().getString();
                String itemCount = selected.getCount() + "x";
                draw.fill(hx - 62, hy - 4, hx + 62, hy + 18, 0xAA080B10);
                draw.drawCenteredTextWithShadow(c.textRenderer, itemName + "  " + itemCount, hx, hy, accentColor);
            }
        }
        if (on("Weather & Time Card")) {
            long timeOfDay = c.world.getTimeOfDay() % 24000L;
            long clockHour = ((timeOfDay / 1000L + 6L) % 24L);
            long clockMinute = (timeOfDay % 1000L) * 60L / 1000L;
            String weather = c.world.isThundering() ? "THUNDER" : c.world.isRaining() ? "RAIN" : "CLEAR";
            int wx = c.getWindow().getScaledWidth() - 95, wy = c.getWindow().getScaledHeight() - 34;
            draw.fill(wx - 5, wy - 4, wx + 90, wy + 25, 0xAA080B10);
            drawHudText(draw, c, String.format(Locale.ROOT, "%02d:%02d", clockHour, clockMinute), wx, wy, accentColor);
            drawHudText(draw, c, weather, wx, wy + 12, weather.equals("CLEAR") ? 0xFFB7FF3C : 0xFF67D9FF);
        }
        if (on("Low Health Vignette")) {
            float hpRatio = c.player.getHealth() / Math.max(1.0f, c.player.getMaxHealth());
            if (hpRatio <= 0.30f) {
                int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
                int pulse = 0x33000000 | ((tickCounter % 20 < 10 ? 0x00FF2222 : 0x00AA1111));
                int band = Math.max(4, Math.min(16, (int)((0.30f - hpRatio) * 60.0f)));
                draw.fill(0, 0, sw, band, pulse); draw.fill(0, sh - band, sw, sh, pulse);
                draw.fill(0, 0, band, sh, pulse); draw.fill(sw - band, 0, sw, sh, pulse);
            }
        }

        if (on("Ping Graph")) {
            int gx = c.getWindow().getScaledWidth() - 94, gy = 68;
            draw.fill(gx - 4, gy - 17, gx + 86, gy + 4, 0xAA080B10);
            drawHudText(draw, c, cachedPing < 0 ? "PING --" : "PING " + cachedPing + " ms", gx, gy - 14,
                cachedPing < 0 ? 0xFFAAAAAA : cachedPing > 150 ? 0xFFFF5555 : cachedPing > 80 ? 0xFFFFBB55 : 0xFFB7FF3C);
            for (int i = 0; i < PING_HISTORY.length; i++) {
                int value = PING_HISTORY[(pingHistoryIndex + i) % PING_HISTORY.length];
                if (value < 0) continue;
                int h = Math.max(1, Math.min(18, value * 18 / 250));
                int color = value > 150 ? 0xFFFF5555 : value > 80 ? 0xFFFFBB55 : accentColor;
                draw.fill(gx + i * 2, gy + 4 - h, gx + i * 2 + 1, gy + 4, color);
            }
        }
        if (on("Block Reach Meter")) {
            int rx = c.getWindow().getScaledWidth() / 2 + 58;
            int ry = c.getWindow().getScaledHeight() / 2 + 20;
            if (c.crosshairTarget instanceof BlockHitResult blockHit) {
                double distance = c.player.getEyePos().distanceTo(blockHit.getPos());
                drawHudText(draw, c, String.format(Locale.ROOT, "BLOCK %.2fm", distance), rx, ry,
                    distance > 4.5 ? 0xFFFFBB55 : accentColor);
            } else {
                drawHudText(draw, c, "BLOCK --", rx, ry, 0xFFAAAAAA);
            }
        }
        if (on("Velocity Vector")) {
            double vx = c.player.getVelocity().x, vz = c.player.getVelocity().z;
            double horizontal = Math.sqrt(vx * vx + vz * vz) * 20.0;
            int vyColor = c.player.getVelocity().y < -0.15 ? 0xFFFFBB55 : c.player.getVelocity().y > 0.15 ? 0xFFB7FF3C : 0xFFFFFFFF;
            drawHudText(draw, c, String.format(Locale.ROOT, "V %.2f b/s  Y %+.2f", horizontal, c.player.getVelocity().y),
                7, c.getWindow().getScaledHeight() - 62, vyColor);
        }
        if (on("Resource Alert Panel")) {
            int tx = c.getWindow().getScaledWidth() - 112, ty = c.getWindow().getScaledHeight() - 58;
            int totems = c.player.getInventory().count(Items.TOTEM_OF_UNDYING);
            int apples = c.player.getInventory().count(Items.GOLDEN_APPLE) + c.player.getInventory().count(Items.ENCHANTED_GOLDEN_APPLE);
            int arrows = c.player.getInventory().count(Items.ARROW) + c.player.getInventory().count(Items.SPECTRAL_ARROW) + c.player.getInventory().count(Items.TIPPED_ARROW);
            draw.fill(tx - 4, ty - 4, tx + 106, ty + 34, 0xAA080B10);
            drawHudText(draw, c, "TOTEM " + totems, tx, ty, totems == 0 ? 0xFFFF5555 : totems == 1 ? 0xFFFFBB55 : 0xFFB7FF3C);
            drawHudText(draw, c, "GAPPLE " + apples, tx, ty + 11, apples == 0 ? 0xFFFF5555 : 0xFFFFFFFF);
            drawHudText(draw, c, "ARROWS " + arrows, tx, ty + 22, arrows == 0 ? 0xFFFFBB55 : 0xFFFFFFFF);
        }
        if (on("Biome & Dimension Card")) {
            String biome = c.world.getBiome(c.player.getBlockPos()).getKey().map(k -> k.getValue().getPath()).orElse("unknown");
            String dimension = c.world.getRegistryKey().getValue().getPath().toUpperCase(Locale.ROOT);
            int bx = c.getWindow().getScaledWidth() - 118, by = 7;
            draw.fill(bx - 4, by - 3, bx + 114, by + 27, 0xAA080B10);
            drawHudText(draw, c, dimension, bx, by, accentColor);
            drawHudText(draw, c, biome, bx, by + 12, 0xFFFFFFFF);
        }
        if (on("Inventory Durability Scan")) {
            int low = 0, worst = 101;
            String worstName = "none";
            for (ItemStack stack : c.player.getInventory().main) {
                if (!stack.isEmpty() && stack.isDamageable()) {
                    int pct = Math.max(0, (stack.getMaxDamage() - stack.getDamage()) * 100 / Math.max(1, stack.getMaxDamage()));
                    if (pct <= durabilityWarningPercent) low++;
                    if (pct < worst) { worst = pct; worstName = stack.getName().getString(); }
                }
            }
            int iy = c.getWindow().getScaledHeight() - 74;
            drawHudText(draw, c, "Low durability items: " + low, 7, iy, low > 0 ? 0xFFFF5555 : 0xFFB7FF3C);
            if (worst <= 100) drawHudText(draw, c, "Weakest: " + worstName + " " + worst + "%", 7, iy + 11, worst <= durabilityWarningPercent ? 0xFFFF5555 : 0xFFFFFFFF);
        }
        if (on("Status Effect Count")) {
            int count = c.player.getStatusEffects().size();
            int sx = c.getWindow().getScaledWidth() / 2, sy = c.getWindow().getScaledHeight() - 76;
            draw.fill(sx - 42, sy - 3, sx + 42, sy + 12, 0xAA080B10);
            draw.drawCenteredTextWithShadow(c.textRenderer, "EFFECTS " + count, sx, sy, count == 0 ? 0xFFAAAAAA : accentColor);
        }
        if (on("Air Safety Meter") && c.player.isSubmergedInWater()) {
            int air = Math.max(0, c.player.getAir());
            int maxAir = Math.max(1, c.player.getMaxAir());
            int percent = Math.max(0, Math.min(100, air * 100 / maxAir));
            int ax = c.getWindow().getScaledWidth() / 2 - 45, ay = c.getWindow().getScaledHeight() / 2 + 34;
            int color = percent <= 25 ? 0xFFFF4444 : percent <= 50 ? 0xFFFFBB55 : 0xFF55FFFF;
            draw.fill(ax, ay, ax + 90, ay + 5, 0xAA222222);
            draw.fill(ax, ay, ax + 90 * percent / 100, ay + 5, color);
            draw.drawCenteredTextWithShadow(c.textRenderer, "AIR " + percent + "%", ax + 45, ay + 7, color);
        }

        if (on("Crosshair Dot") || on("Dynamic Crosshair")) {
            int cx = c.getWindow().getScaledWidth() / 2;
            int cy = c.getWindow().getScaledHeight() / 2;
            int size = Math.max(1, Math.min(8, crosshairSize));
            int crossColor = on("Crosshair Hit Color") && c.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity
                ? 0xFFFF5555 : accentColor;
            if (on("Crosshair Dot")) draw.fill(cx - size / 2, cy - size / 2, cx - size / 2 + size, cy - size / 2 + size, crossColor);
            if (on("Dynamic Crosshair")) {
                double speed = Math.sqrt(c.player.getVelocity().x * c.player.getVelocity().x + c.player.getVelocity().z * c.player.getVelocity().z);
                int gap = crosshairGap + (int)Math.min(8, speed * 20.0);
                int thickness = Math.max(1, Math.min(5, crosshairThickness));
                draw.fill(cx - thickness / 2, cy - gap - 4, cx - thickness / 2 + thickness, cy - gap, crossColor);
                draw.fill(cx - thickness / 2, cy + gap + 1, cx - thickness / 2 + thickness, cy + gap + 5, crossColor);
                draw.fill(cx - gap - 4, cy - thickness / 2, cx - gap, cy - thickness / 2 + thickness, crossColor);
                draw.fill(cx + gap + 1, cy - thickness / 2, cx + gap + 5, cy - thickness / 2 + thickness, crossColor);
            }
        }
        if (on("Module List")) {
            int yy = 7;
            for (Feature f : FEATURES.values()) if (f.enabled && !Set.of("Module List", "Show Server Address").contains(f.name)) {
                String label = f.name;
                int x = c.getWindow().getScaledWidth() - c.textRenderer.getWidth(label) - 8;
                drawHudText(draw, c, label, x, yy, accentColor); yy += 10;
            }
        }
        draw.getMatrices().pop();
    }

    private static void drawHudText(DrawContext draw, MinecraftClient client, String value, int x, int y, int color) {
        if (on("HUD Text Background") && hudBackgroundOpacity > 0) {
            int alpha = Math.max(0, Math.min(255, hudBackgroundOpacity));
            int background = (alpha << 24);
            draw.fill(x - 2, y - 1, x + client.textRenderer.getWidth(value) + 2, y + 10, background);
        }
        draw.drawTextWithShadow(client.textRenderer, value, x, y, color);
    }

    private static void drawHudText(DrawContext draw, MinecraftClient client, Text value, int x, int y, int color) {
        if (on("HUD Text Background") && hudBackgroundOpacity > 0) {
            int alpha = Math.max(0, Math.min(255, hudBackgroundOpacity));
            draw.fill(x - 2, y - 1, x + client.textRenderer.getWidth(value) + 2, y + 10, (alpha << 24));
        }
        draw.drawTextWithShadow(client.textRenderer, value, x, y, color);
    }

    private static String key(KeyBinding binding) {
        return binding.isPressed() ? "[" + binding.getBoundKeyLocalizedText().getString() + "]" : binding.getBoundKeyLocalizedText().getString();
    }
    private static int countItem(net.minecraft.item.Item item) {
        if (MC.player == null) return 0;
        int count = 0;
        for (ItemStack stack : MC.player.getInventory().main) if (stack.isOf(item)) count += stack.getCount();
        return count;
    }

    private static boolean on(String name) { Feature f = FEATURES.get(name); return f != null && f.enabled; }

    private static void loadConfig() {
        try {
            if (Files.exists(ACTIVE_PROFILE_FILE)) {
                String stored = Files.readString(ACTIVE_PROFILE_FILE).trim().toLowerCase(Locale.ROOT);
                if (Set.of("default", "pvp", "minimal").contains(stored)) activeProfile = stored;
            }
        } catch (IOException e) {
            System.err.println("[ZEWS VISUALS] Could not read active profile: " + e.getMessage());
        }
        Path file = configFile();
        if (!Files.exists(file)) return;
        try {
            JsonObject root = GSON.fromJson(Files.readString(file), JsonObject.class);
            if (root == null) return;
            for (Feature f : FEATURES.values()) {
                if (root.has(f.name) && root.get(f.name).isJsonPrimitive() && root.getAsJsonPrimitive(f.name).isBoolean()) f.enabled = root.get(f.name).getAsBoolean();
            }
            if (root.has("crosshairSize")) crosshairSize = Math.max(1, Math.min(8, root.get("crosshairSize").getAsInt()));
            if (root.has("accentColor")) accentColor = root.get("accentColor").getAsInt();
            if (root.has("lowHealthThreshold")) lowHealthThreshold = Math.max(2, Math.min(10, root.get("lowHealthThreshold").getAsInt()));
            if (root.has("hudScale")) hudScale = Math.max(0.65f, Math.min(1.5f, root.get("hudScale").getAsFloat()));
            if (root.has("hudBackgroundOpacity")) hudBackgroundOpacity = Math.max(0, Math.min(220, root.get("hudBackgroundOpacity").getAsInt()));
            if (root.has("durabilityWarningPercent")) durabilityWarningPercent = Math.max(5, Math.min(50, root.get("durabilityWarningPercent").getAsInt()));
            if (root.has("crosshairGap")) crosshairGap = Math.max(1, Math.min(12, root.get("crosshairGap").getAsInt()));
            if (root.has("crosshairThickness")) crosshairThickness = Math.max(1, Math.min(5, root.get("crosshairThickness").getAsInt()));
            accentColor = 0xFF000000 | (accentColor & 0x00FFFFFF);
        } catch (Exception e) {
            System.err.println("[ZEWS VISUALS] Could not load config: " + e.getMessage());
        }
    }

    private static void saveConfig() {
        JsonObject root = new JsonObject();
        root.addProperty("schemaVersion", 3);
        root.addProperty("crosshairSize", crosshairSize);
        root.addProperty("accentColor", accentColor);
        root.addProperty("lowHealthThreshold", lowHealthThreshold);
        root.addProperty("hudScale", hudScale);
        root.addProperty("hudBackgroundOpacity", hudBackgroundOpacity);
        root.addProperty("durabilityWarningPercent", durabilityWarningPercent);
        root.addProperty("crosshairGap", crosshairGap);
        root.addProperty("crosshairThickness", crosshairThickness);
        for (Feature f : FEATURES.values()) root.addProperty(f.name, f.enabled);
        Path file = configFile();
        try {
            Files.createDirectories(file.getParent());
            if (Files.exists(file)) {
                Path backup = file.resolveSibling(file.getFileName().toString() + ".bak");
                Files.copy(file, backup, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
            Path temp = file.resolveSibling(file.getFileName().toString() + ".tmp");
            Files.writeString(temp, GSON.toJson(root));
            try {
                Files.move(temp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ignored) {
                Files.move(temp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
            Files.writeString(ACTIVE_PROFILE_FILE, activeProfile);
        } catch (IOException e) {
            System.err.println("[ZEWS VISUALS] Could not save config: " + e.getMessage());
        }
    }

    private static void exportConfig() {
        try {
            saveConfig();
            Path export = CONFIG.resolveSibling("zewsvisuals-export.json");
            Files.copy(configFile(), export, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            Path profileExport = CONFIG.resolveSibling("zewsvisuals-export-" + activeProfile + ".json");
            Files.copy(configFile(), profileExport, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            System.out.println("[ZEWS VISUALS] Config exported to " + export + " and " + profileExport);
        } catch (IOException e) {
            System.err.println("[ZEWS VISUALS] Config export failed: " + e.getMessage());
        }
    }

    private static void importConfig() {
        Path export = CONFIG.resolveSibling("zewsvisuals-export.json");
        try {
            if (!Files.exists(export)) {
                System.err.println("[ZEWS VISUALS] Import file not found: " + export);
                return;
            }
            JsonObject imported = GSON.fromJson(Files.readString(export), JsonObject.class);
            if (imported == null || imported.isJsonNull()) throw new IOException("Export JSON is empty or invalid");
            // Validate before replacing the live config. Unknown fields are safely ignored.
            for (Feature f : FEATURES.values()) {
                if (imported.has(f.name) && (!imported.get(f.name).isJsonPrimitive() || !imported.getAsJsonPrimitive(f.name).isBoolean()))
                    throw new IOException("Invalid value for feature: " + f.name);
            }
            for (String key : List.of("schemaVersion", "crosshairSize", "accentColor", "lowHealthThreshold", "hudBackgroundOpacity", "durabilityWarningPercent", "crosshairGap", "crosshairThickness")) {
                if (imported.has(key) && (!imported.get(key).isJsonPrimitive() || !imported.getAsJsonPrimitive(key).isNumber()))
                    throw new IOException("Invalid numeric setting: " + key);
            }
            if (imported.has("hudScale") && (!imported.get("hudScale").isJsonPrimitive() || !imported.getAsJsonPrimitive("hudScale").isNumber()))
                throw new IOException("Invalid numeric setting: hudScale");
            Files.createDirectories(CONFIG.getParent());
            Path current = configFile();
            if (Files.exists(current)) Files.copy(current, current.resolveSibling(current.getFileName().toString() + ".bak"), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            Files.copy(export, current, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            loadConfig();
            System.out.println("[ZEWS VISUALS] Config imported successfully");
        } catch (Exception e) {
            System.err.println("[ZEWS VISUALS] Config import failed: " + e.getMessage());
        }
    }

    private static void resetFeaturesForProfile(String profile) {
        for (Feature f : FEATURES.values()) f.enabled = false;
        Set<String> enabled = switch (profile) {
            case "pvp" -> Set.of("Watermark", "FPS Counter", "Coordinates", "Direction", "CPS Counter", "Keystrokes", "Module List", "Low Health Warning", "Target Name", "Target Health", "Target Distance", "Totem Count", "Golden Apple Count", "Armor Icons", "Health Bar", "HUD Visibility Hotkey");
            case "minimal" -> Set.of("Watermark", "FPS Counter", "Coordinates", "Direction", "Module List");
            default -> Set.of("Watermark", "FPS Counter", "Coordinates", "Direction", "CPS Counter", "Module List", "View Bobbing");
        };
        for (String name : enabled) if (FEATURES.containsKey(name)) FEATURES.get(name).enabled = true;
        crosshairSize = 2;
        accentColor = 0xFF55FFFF;
        lowHealthThreshold = 6;
        hudScale = 1.0f;
        hudBackgroundOpacity = 72;
        durabilityWarningPercent = 10;
        crosshairGap = 4;
        crosshairThickness = 2;
        lastAppliedBobbing = null;
    }

    private static final class Feature {
        final String name, category;
        boolean enabled;
        Feature(String name, String category, boolean enabled) { this.name = name; this.category = category; this.enabled = enabled; }
    }

    private static final class FeatureScreen extends Screen {
        private int page;
        private String filterCategory = "All";
        private String searchText = "";
        private TextFieldWidget searchField;
        private static final int PAGE_SIZE = 12;
        private List<Feature> filteredFeatures() {
            List<Feature> list = new ArrayList<>();
            String query = searchText.trim().toLowerCase(Locale.ROOT);
            for (Feature f : FEATURES.values()) {
                boolean categoryMatches = filterCategory.equals("All") || f.category.equals(filterCategory);
                boolean searchMatches = query.isEmpty() || f.name.toLowerCase(Locale.ROOT).contains(query) || f.category.toLowerCase(Locale.ROOT).contains(query);
                if (categoryMatches && searchMatches) list.add(f);
            }
            return list;
        }
        private String nextCategory() {
            List<String> categories = new ArrayList<>();
            categories.add("All");
            for (Feature f : FEATURES.values()) if (!categories.contains(f.category)) categories.add(f.category);
            int index = categories.indexOf(filterCategory);
            return categories.get((index + 1 + categories.size()) % categories.size());
        }
        FeatureScreen() { super(Text.literal("ZEWS VISUALS")); }
        @Override protected void init() { rebuild(); }
        private void rebuild() {
            clearChildren();
            searchField = new TextFieldWidget(textRenderer, width / 2 - 145, 33, 250, 18, Text.literal("Search modules"));
            searchField.setMaxLength(64);
            searchField.setText(searchText);
            searchField.setChangedListener(value -> searchText = value);
            addDrawableChild(searchField);
            addDrawableChild(ButtonWidget.builder(Text.literal("Search"), b -> { page = 0; rebuild(); })
                .dimensions(width / 2 + 110, 33, 55, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Clear"), b -> { searchText = ""; page = 0; rebuild(); })
                .dimensions(width / 2 + 169, 33, 48, 18).build());
            List<Feature> list = filteredFeatures();
            int maxPage = Math.max(0, (list.size() - 1) / PAGE_SIZE);
            page = Math.min(page, maxPage);
            int start = page * PAGE_SIZE, end = Math.min(list.size(), start + PAGE_SIZE);
            int colWidth = Math.max(100, Math.min(250, (width - 48) / 2));
            for (int i = start; i < end; i++) {
                Feature f = list.get(i);
                int local = i - start, col = local / 6, row = local % 6;
                int x = width / 2 - colWidth - 6 + col * (colWidth + 12);
                int y = 52 + row * 21;
                addDrawableChild(ButtonWidget.builder(label(f), b -> {
                    f.enabled = !f.enabled;
                    b.setMessage(label(f));
                    saveConfig();
                }).dimensions(x, y, colWidth, 20).build());
            }
            addDrawableChild(ButtonWidget.builder(Text.literal("‹"), b -> { page = Math.max(0, page - 1); rebuild(); })
                .dimensions(12, height - 58, 36, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("›"), b -> { page = Math.min(maxPage, page + 1); rebuild(); })
                .dimensions(width - 48, height - 58, 36, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("All ON"), b -> { for (Feature f : FEATURES.values()) f.enabled = true; saveConfig(); rebuild(); })
                .dimensions(width / 2 - 112, height - 58, 55, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("All OFF"), b -> { for (Feature f : FEATURES.values()) f.enabled = false; saveConfig(); rebuild(); })
                .dimensions(width / 2 - 52, height - 58, 58, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Color"), b -> { accentColor = accentColor == 0xFF55FFFF ? 0xFFFF55FF : accentColor == 0xFFFF55FF ? 0xFF55FF55 : 0xFF55FFFF; saveConfig(); })
                .dimensions(width / 2 + 10, height - 58, 48, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Dot size"), b -> { crosshairSize = crosshairSize >= 8 ? 1 : crosshairSize + 1; saveConfig(); rebuild(); })
                .dimensions(width / 2 + 62, height - 58, 58, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Gap " + crosshairGap), b -> {
                crosshairGap = crosshairGap >= 12 ? 1 : crosshairGap + 1;
                saveConfig(); rebuild();
            }).dimensions(width / 2 + 126, height - 58, 55, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Thick " + crosshairThickness), b -> {
                crosshairThickness = crosshairThickness >= 5 ? 1 : crosshairThickness + 1;
                saveConfig(); rebuild();
            }).dimensions(width / 2 + 187, height - 58, 65, 20).build());
            redField = new TextFieldWidget(textRenderer, width / 2 - 100, height - 82, 34, 18, Text.literal("R"));
            greenField = new TextFieldWidget(textRenderer, width / 2 - 62, height - 82, 34, 18, Text.literal("G"));
            blueField = new TextFieldWidget(textRenderer, width / 2 - 24, height - 82, 34, 18, Text.literal("B"));
            redField.setMaxLength(3); greenField.setMaxLength(3); blueField.setMaxLength(3);
            redField.setText(Integer.toString((accentColor >> 16) & 255));
            greenField.setText(Integer.toString((accentColor >> 8) & 255));
            blueField.setText(Integer.toString(accentColor & 255));
            addDrawableChild(redField); addDrawableChild(greenField); addDrawableChild(blueField);
            addDrawableChild(ButtonWidget.builder(Text.literal("Apply RGB"), b -> {
                try {
                    int r = Math.max(0, Math.min(255, Integer.parseInt(redField.getText())));
                    int g = Math.max(0, Math.min(255, Integer.parseInt(greenField.getText())));
                    int bl = Math.max(0, Math.min(255, Integer.parseInt(blueField.getText())));
                    accentColor = 0xFF000000 | (r << 16) | (g << 8) | bl;
                    saveConfig(); rebuild();
                } catch (NumberFormatException ignored) { }
            }).dimensions(width / 2 + 16, height - 82, 68, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Scale " + String.format(Locale.ROOT, "%.2f", hudScale)), b -> {
                hudScale = hudScale >= 1.49f ? 0.65f : Math.min(1.5f, hudScale + 0.15f);
                saveConfig(); rebuild();
            }).dimensions(width / 2 + 88, height - 82, 70, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("BG " + hudBackgroundOpacity), b -> {
                hudBackgroundOpacity = hudBackgroundOpacity >= 220 ? 0 : hudBackgroundOpacity + 44;
                saveConfig(); rebuild();
            }).dimensions(width / 2 + 164, height - 82, 60, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Dur " + durabilityWarningPercent + "%"), b -> {
                durabilityWarningPercent = durabilityWarningPercent >= 50 ? 5 : durabilityWarningPercent + 5;
                saveConfig(); rebuild();
            }).dimensions(width / 2 + 230, height - 82, 65, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal(filterCategory.equals("All") ? "Filter: All" : "Filter: " + filterCategory), b -> { filterCategory = nextCategory(); page = 0; rebuild(); })
                .dimensions(width / 2 - 305, height - 32, 100, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("HP≤" + lowHealthThreshold), b -> { lowHealthThreshold = lowHealthThreshold >= 10 ? 2 : lowHealthThreshold + 2; saveConfig(); rebuild(); })
                .dimensions(width / 2 - 192, height - 32, 45, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Profile"), b -> {
                saveConfig();
                activeProfile = switch (activeProfile) { case "default" -> "pvp"; case "pvp" -> "minimal"; default -> "default"; };
                try { Files.writeString(ACTIVE_PROFILE_FILE, activeProfile); } catch (IOException e) { System.err.println("[ZEWS VISUALS] Could not switch profile: " + e.getMessage()); }
                resetFeaturesForProfile(activeProfile); loadConfig(); saveConfig(); rebuild();
            }).dimensions(width / 2 - 142, height - 32, 55, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Import"), b -> { importConfig(); rebuild(); })
                .dimensions(width / 2 - 82, height - 32, 45, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Export"), b -> exportConfig())
                .dimensions(width / 2 - 32, height - 32, 45, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal(filterCategory.equals("All") ? "Reset" : "Reset cat."), b -> {
                if (filterCategory.equals("All")) {
                    resetFeaturesForProfile(activeProfile);
                } else {
                    for (Feature f : FEATURES.values()) if (f.category.equals(filterCategory)) f.enabled = false;
                }
                saveConfig(); rebuild();
            }).dimensions(width / 2 + 18, height - 32, 62, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(width / 2 + 68, height - 32, 50, 20).build());
        }
        private Text label(Feature f) {
            return Text.literal((f.enabled ? "ON  " : "OFF ") + f.name + "  ·  " + f.category)
                .formatted(f.enabled ? Formatting.AQUA : Formatting.GRAY);
        }
        @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
            renderBackground(context, mouseX, mouseY, delta);
            context.drawCenteredTextWithShadow(textRenderer, Text.literal("ZEWS VISUALS").formatted(Formatting.AQUA, Formatting.BOLD), width / 2, 8, 0xFFFFFF);
            int visibleCount = filteredFeatures().size();
            long enabledCount = FEATURES.values().stream().filter(f -> f.enabled).count();
            context.drawCenteredTextWithShadow(textRenderer, Text.literal(enabledCount + "/" + FEATURES.size() + " enabled • " + visibleCount + " found • " + activeProfile + " • page " + (page + 1) + "/" + Math.max(1, ((visibleCount-1)/PAGE_SIZE)+1)), width / 2, 21, 0xAAAAAA);
            super.render(context, mouseX, mouseY, delta);
        }
        @Override public boolean shouldPause() { return false; }
        @Override public void close() { saveConfig(); super.close(); }
    }
}
